# Gas Engineering Services Website
This is a free, editable starter website. Open `index.html` in a browser to preview it.

Before publishing:
1. Replace `YOUR PHONE NUMBER` with the real number.
2. Replace `YOUR EMAIL ADDRESS`.
3. Choose the final business name and update it throughout `index.html`.
4. Check the exact services, qualifications and areas covered.
5. Only add Gas Safe registration details/badges if the engineer is actually registered.
6. Connect the contact form to an email/form service before relying on it for enquiries.

No paid libraries or website-builder subscription is required for this version.
